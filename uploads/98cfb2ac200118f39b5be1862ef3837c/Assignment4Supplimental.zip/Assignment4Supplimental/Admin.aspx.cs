﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace Assignment4Supplemental
{
	public partial class Admin : System.Web.UI.Page
	{
		
		protected void Page_Load( object sender, EventArgs e )
		{
			if (!Page.IsPostBack)
			{
				this.UpdateGridFromSQL();
			}
		}

		private void UpdateGridFromSQL()
		{
			using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
			{
				connection.Open();
				//The following stored procedure is what I am using to get all submissions
				/*
					CREATE PROCEDURE [dbo].[GetAllSubmissions]
					AS
					BEGIN
						SET NOCOUNT ON;
						SELECT [SubmissionId],[Name],[Email] FROM Submission
					END
 
					 
				 */
				using (SqlCommand command = new SqlCommand( "GetAllSubmissions", connection ))
				{
					command.CommandType = CommandType.StoredProcedure;
					SqlDataReader reader = command.ExecuteReader( CommandBehavior.CloseConnection );
					this.grdView.DataSource = reader;
					this.grdView.DataBind();
				}
			}
		}
		protected void grdView_Bound( object sender, GridViewRowEventArgs e )
		{
			if (e.Row.RowIndex == this.grdView.EditIndex)
			{
				Repeater rptColorsEdit = e.Row.FindControl( "rptColorsEdit" ) as Repeater;
				if (rptColorsEdit != null)
				{
					int submissionId = (int)this.grdView.DataKeys[e.Row.RowIndex].Value;
					using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
					{
						connection.Open();
						//Below is the stored procedure that I am executing for getting all colors
						/*
						 * CREATE PROCEDURE GetAllColors
							AS
							BEGIN
								SET NOCOUNT ON;
								SELECT [ColorId],[Name] FROM Color
							END
						 */
						using (SqlCommand command = new SqlCommand( "GetAllColors", connection ))
						{
							command.CommandType = CommandType.StoredProcedure;
							SqlDataReader reader = command.ExecuteReader( CommandBehavior.CloseConnection );
							rptColorsEdit.DataSource = reader;
							rptColorsEdit.DataBind();
						}
					}
				}
			}
			else
			{
				Repeater rptColors = e.Row.FindControl( "rptColors" ) as Repeater;
				if (rptColors != null)
				{
					int submissionId = (int)this.grdView.DataKeys[e.Row.RowIndex].Value;
					using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
					{
						connection.Open();
						//The following stored procedure is what I use to get colors that the user selected back from the database
						/*
							CREATE PROCEDURE GetColorsForSubmission
								@SubmissionId INT
							AS
							BEGIN

								SET NOCOUNT ON;
								SELECT [Color].[ColorId], [Name] FROM SubmissionColor INNER JOIN Color ON Color.ColorId = SubmissionColor.ColorId WHERE SubmissionId = @SubmissionId
							END
						 */
						using (SqlCommand command = new SqlCommand( "GetColorsForSubmission", connection ))
						{
							command.Parameters.AddWithValue( "SubmissionId", submissionId );
							command.CommandType = CommandType.StoredProcedure;
							SqlDataReader reader = command.ExecuteReader( CommandBehavior.CloseConnection );
							rptColors.DataSource = reader;
							rptColors.DataBind();
						}
					}
				}
			}
		}

		protected void grdView_CancelingEdit( object sender, GridViewCancelEditEventArgs e )
		{
			this.grdView.EditIndex = -1;
			this.UpdateGridFromSQL();
		}
		protected void grdView_Editting( object sender, GridViewEditEventArgs e )
		{
			this.grdView.EditIndex = e.NewEditIndex;
			this.UpdateGridFromSQL();
			
		}
		protected void rptColorsEdit_DataItemBound( object sender, RepeaterItemEventArgs e )
		{
			HiddenField hidColorId = e.Item.FindControl( "hidColorId" ) as HiddenField;
			CheckBox chkBox = e.Item.FindControl( "chkBox" ) as CheckBox;
			int colorId = 0;
			int submissionId = (int)this.grdView.DataKeys[this.grdView.EditIndex].Value;
			List<int> editRowColorIds = new List<int>();
			using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
			{
				connection.Open();
				//The following stored procedure is what I use to get colors that the user selected back from the database
				/*
					CREATE PROCEDURE GetColorsForSubmission
						@SubmissionId INT
					AS
					BEGIN

						SET NOCOUNT ON;
						SELECT [Color].[ColorId], [Name] FROM SubmissionColor INNER JOIN Color ON Color.ColorId = SubmissionColor.ColorId WHERE SubmissionId = @SubmissionId
					END
				 */
				using (SqlCommand command = new SqlCommand( "GetColorsForSubmission", connection ))
				{
					command.Parameters.AddWithValue( "SubmissionId", submissionId );
					command.CommandType = CommandType.StoredProcedure;
					SqlDataReader reader = command.ExecuteReader( CommandBehavior.CloseConnection );
					while (reader.Read())
					{
						editRowColorIds.Add( (int)reader["ColorId"] );
					}
					reader.Close();
					reader.Dispose();
				}
			}
			if (hidColorId != null && chkBox != null)
			{
				if (int.TryParse( hidColorId.Value, out colorId ))
				{
					if (editRowColorIds.Contains( colorId ))
					{
						chkBox.Checked = true;
					}
				}
			}
		}
		protected void grdView_Updating( object sender, GridViewUpdateEventArgs e )
		{
			int submissionId = (int)this.grdView.DataKeys[e.RowIndex].Value;
            GridViewRow row = this.grdView.Rows[e.RowIndex] as GridViewRow;

			TextBox txtName = row.FindControl( "txtName" ) as TextBox;
			TextBox txtEmail = row.FindControl("txtEmail") as TextBox;
			using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
			{
				connection.Open();
				//The following stored procedure is what I use to get colors that the user selected back from the database
				/*
					CREATE PROCEDURE [dbo].[UpdateSubmission]
						@SubmissionId INT,
						@Name VARCHAR(20),
						@Email VARCHAR(10)
					AS
					BEGIN

						SET NOCOUNT ON;
						UPDATE Submission SET [Name] = @Name, @Email = [Email] WHERE SubmissionId = @SubmissionId
					END

				 */
				using (SqlCommand command = new SqlCommand( "UpdateSubmission", connection ))
				{
					command.Parameters.AddWithValue( "SubmissionId", submissionId );
					command.Parameters.AddWithValue( "Name", txtName.Text );
					command.Parameters.AddWithValue( "Email", txtEmail.Text );
					command.CommandType = CommandType.StoredProcedure;
					command.ExecuteNonQuery();
						//The following stored procedure is what I use to clear out all colors for the submission since we are going to rebuild this
						// You could also delete ones that aren't checked and then add new ones, but that gets messy quick
						/*
							CREATE PROCEDURE DeleteAllColorsForSubmission
								@SubmissionId INT
							AS
							BEGIN
								DELETE FROM SubmissionColor WHERE SubmissionId = @SubmissionId
							END
						 */
					command.Parameters.Clear();
					command.CommandText = "DeleteAllColorsForSubmission";
					command.Parameters.AddWithValue( "SubmissionId", submissionId );
					command.ExecuteNonQuery();
					command.CommandText = "AddColorToSubmission";
					Repeater rptColorsEdit = row.FindControl( "rptColorsEdit" ) as Repeater;
					if (rptColorsEdit != null)
					{
						foreach (RepeaterItem item in rptColorsEdit.Items)
						{
							HiddenField hidColorId = item.FindControl( "hidColorId" ) as HiddenField;
							CheckBox chkBox = item.FindControl( "chkBox" ) as CheckBox;
							if (hidColorId != null && chkBox != null) //Ensure that both controls are found before trying to work with them
							{
								int colorId = 0;

								if (chkBox.Checked && int.TryParse( hidColorId.Value, out colorId ))
								{
									command.Parameters.Clear(); // Since the command has been used before, we need to clear out the previous parameters
									command.Parameters.AddWithValue( "SubmissionId", submissionId );
									command.Parameters.AddWithValue( "ColorId", colorId );
									command.ExecuteNonQuery();
								}
							}
						}
					}
					connection.Close();
				}

			}
			this.grdView.EditIndex = -1;
			this.UpdateGridFromSQL();
		}
		protected void grdView_Deleting( object sender, GridViewDeleteEventArgs e )
		{
			int submissionId = (int)this.grdView.DataKeys[e.RowIndex].Value;
		
			using (SqlConnection connection = new SqlConnection( System.Configuration.ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
			{
				connection.Open();
				//The following stored procedure is what I use to delete a submission. Keep in mind that I have a CASCADE rule set on my Relationship between the Submission table and the SubmissionColor table.
				//If you do not have a cascade you would need to delete the rows out of SubmissionColor before your deleted the row out of submission
				/*
					CREATE PROCEDURE DeleteAllColorsForSubmission
						@SubmissionId INT
					AS
					BEGIN
						DELETE FROM SubmissionColor WHERE SubmissionId = @SubmissionId
					END
				 */
				using (SqlCommand command = new SqlCommand( "DeleteSubmission", connection ))
				{
					command.Parameters.AddWithValue( "SubmissionId", submissionId );
					command.CommandType = CommandType.StoredProcedure;
					command.ExecuteNonQuery();
				}
				connection.Close();
			}

			this.UpdateGridFromSQL();
		}
	}
}