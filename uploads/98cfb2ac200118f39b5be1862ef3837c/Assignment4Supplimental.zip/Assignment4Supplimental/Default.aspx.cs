﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Assignment4Supplemental
{
	public partial class Default : System.Web.UI.Page
	{
		protected void Page_Load( object sender, EventArgs e )
		{

			if (!Page.IsPostBack)
			{
				//Below is the stored procedure that I am executing for getting all colors
				/*
				 * CREATE PROCEDURE GetAllColors
					AS
					BEGIN
						SET NOCOUNT ON;
						SELECT [ColorId],[Name] FROM Color
					END
				 */
				using (SqlConnection connection = new SqlConnection( ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
				{
					connection.Open();
					using (SqlCommand command = new SqlCommand( "GetAllColors", connection ))
					{
						SqlDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);//Executing the reader and telling the connection to close after we are done
						this.rptColor.DataSource = reader;
						this.rptColor.DataBind();
						reader.Dispose();
					}
				}
			}
		}

		protected void btnSubmit_Click( object sender, EventArgs e )
		{
			if (Page.IsValid) //Check to make sure all validators are valid on the page
			{


				//Below is the stored procedure that I am using to add a new submission
				/*
					CREATE PROCEDURE [dbo].[AddSubmission]
						@Name VARCHAR(20),
						@Email VARCHAR(10)
					AS
					BEGIN

						SET NOCOUNT ON;
						INSERT INTO Submission (Name,Email) VALUES (@Name, @Email)
						SELECT CAST(SCOPE_IDENTITY() as INT) //SCOPE_IDENTITY will default to decimal, so we need to cast it to the int we are expecting
					END

				  
				 */
				using (SqlConnection connection = new SqlConnection( ConfigurationManager.ConnectionStrings["Submissions"].ConnectionString ))
				{
					connection.Open();
					int submissionId = 0;
					using (SqlCommand command = new SqlCommand( "AddSubmission", connection ))
					{
						command.CommandType = System.Data.CommandType.StoredProcedure; //Make sure the command is a stored procedure
						command.Parameters.AddWithValue( "Name", this.txtName.Text );
						command.Parameters.AddWithValue( "Email", this.txtEmail.Text );
						submissionId = (int)command.ExecuteScalar(); //This time we don't want the connection to close because we are going to be inserting our selected colors
						//Below is the stored procedure I am using to add a color to submission
						/*
							CREATE PROCEDURE [dbo].[AddColorToSubmission]
								@SubmissionId INT,
								@ColorId INT
							AS
							BEGIN
								INSERT INTO SubmissionColor (SubmissionId,ColorId) VALUES (@SubmissionId, @ColorId)
							END
						 */
						command.CommandText = "AddColorToSubmission";
						foreach (RepeaterItem item in this.rptColor.Items)
						{
							HiddenField hidColorId = item.FindControl( "hidColorId" ) as HiddenField;
							CheckBox chkBox = item.FindControl( "chkBox" ) as CheckBox;
							if (hidColorId != null && chkBox != null) //Ensure that both controls are found before trying to work with them
							{
								int colorId = 0;

								if (chkBox.Checked && int.TryParse(hidColorId.Value, out colorId)) 
								{
									command.Parameters.Clear(); // Since the command has been used before, we need to clear out the previous parameters
									command.Parameters.AddWithValue( "SubmissionId", submissionId );
									command.Parameters.AddWithValue( "ColorId", colorId );
									command.ExecuteNonQuery();
								}
							}
						}

					}
					connection.Close();//Make sure to close our connection to the SQL Server
				}
			}
		}
	}
}